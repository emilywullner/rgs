# RGS

Rohstoff-Vermittlungsplattform

## Beschreibung
RGS bringt Anbieter und Käufer von Rohstoffen zusammen.
import './style.css';
document.getElementById('root').innerText = 'Willkommen bei RGS!';